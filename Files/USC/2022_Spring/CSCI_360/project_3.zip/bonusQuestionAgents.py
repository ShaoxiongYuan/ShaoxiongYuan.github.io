"""Custom agent code for the bonus question."""
import util
from featureExtractors import *
from game import Actions
from qlearningAgents import ApproximateQAgent, PacmanQAgent


####################
# Bonus Question 1 #
####################


class CustomExtractor1(FeatureExtractor):
    """Extracts your custom features from the game state."""

    def getFeatures(self, state, action):
        "*** YOUR CODE HERE ***"

        # Currently, this code is copied from SimpleExtractor in
        # featureExtractors.py. It includes simple features for a basic reflex Pacman:
        # - whether food will be eaten
        # - how far away the next food is
        # - whether a ghost collision is imminent
        # - whether a ghost is one step away

        # Feel free to add or remove features as you see fit.

        # extract the grid of food and wall locations and get the ghost locations
        food = state.getFood()
        walls = state.getWalls()
        ghosts = state.getGhostPositions()

        features = util.Counter()

        features["bias"] = 1.0

        # compute the location of pacman after he takes the action
        x, y = state.getPacmanPosition()
        dx, dy = Actions.directionToVector(action)
        next_x, next_y = int(x + dx), int(y + dy)

        # count the number of ghosts 1-step away
        features["#-of-ghosts-1-step-away"] = sum(
            (next_x, next_y) in Actions.getLegalNeighbors(g, walls)
            for g in ghosts)

        # if there is no danger of ghosts then add the food feature
        if not features["#-of-ghosts-1-step-away"] and food[next_x][next_y]:
            features["eats-food"] = 1.0

        dist = closestFood((next_x, next_y), food, walls)
        if dist is not None:
            # make the distance a number less than one otherwise the update
            # will diverge wildly
            features["closest-food"] = float(dist) / (walls.width *
                                                      walls.height)
        features.divideAll(10.0)
        return features


class CustomQAgent1(ApproximateQAgent):
    """Custom Q-learning agent."""

    def __init__(self, extractor='CustomExtractor1', **args):
        self.featExtractor: FeatureExtractor = util.lookup(
            extractor, globals())()
        PacmanQAgent.__init__(self, **args)
        self.weights = util.Counter()

        # Feel free to modify these parameters.
        "*** YOUR CODE HERE ***"
        self.epsilon = 0.05
        self.discount = 0.8
        self.alpha = 0.2

    def update(self, state, action, nextState, reward):
        # Currently, this just calls the ApproximateQAgent update rule. Feel
        # free to modify it as you see fit.
        "*** YOUR CODE HERE ***"
        ApproximateQAgent.update(self, state, action, nextState, reward)


####################
# Bonus Question 2 #
####################


class CustomExtractor2(FeatureExtractor):
    """Extracts your custom features from the game state."""

    def getFeatures(self, state, action):
        "*** YOUR CODE HERE ***"

        # Currently, this code is copied from SimpleExtractor in
        # featureExtractors.py. It includes simple features for a basic reflex Pacman:
        # - whether food will be eaten
        # - how far away the next food is
        # - whether a ghost collision is imminent
        # - whether a ghost is one step away

        # Feel free to add or remove features as you see fit.

        # extract the grid of food and wall locations and get the ghost locations
        food = state.getFood()
        walls = state.getWalls()
        ghosts = state.getGhostPositions()

        features = util.Counter()

        features["bias"] = 1.0

        # compute the location of pacman after he takes the action
        x, y = state.getPacmanPosition()
        dx, dy = Actions.directionToVector(action)
        next_x, next_y = int(x + dx), int(y + dy)

        # count the number of ghosts 1-step away
        features["#-of-ghosts-1-step-away"] = sum(
            (next_x, next_y) in Actions.getLegalNeighbors(g, walls)
            for g in ghosts)

        # if there is no danger of ghosts then add the food feature
        if not features["#-of-ghosts-1-step-away"] and food[next_x][next_y]:
            features["eats-food"] = 1.0

        dist = closestFood((next_x, next_y), food, walls)
        if dist is not None:
            # make the distance a number less than one otherwise the update
            # will diverge wildly
            features["closest-food"] = float(dist) / (walls.width *
                                                      walls.height)
        features.divideAll(10.0)
        return features


class CustomQAgent2(ApproximateQAgent):
    """Custom Q-learning agent."""

    def __init__(self, extractor='CustomExtractor2', **args):
        self.featExtractor: FeatureExtractor = util.lookup(
            extractor, globals())()
        PacmanQAgent.__init__(self, **args)
        self.weights = util.Counter()

        # Feel free to modify these parameters.
        "*** YOUR CODE HERE ***"
        self.epsilon = 0.05
        self.discount = 0.8
        self.alpha = 0.2

    def update(self, state, action, nextState, reward):
        # Currently, this just calls the ApproximateQAgent update rule. Feel
        # free to modify it as you see fit.
        "*** YOUR CODE HERE ***"
        ApproximateQAgent.update(self, state, action, nextState, reward)
