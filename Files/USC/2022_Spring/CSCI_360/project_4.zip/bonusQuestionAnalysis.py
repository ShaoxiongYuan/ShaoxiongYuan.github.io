"""
Bonus Question Analysis
"""

"Which of these metrics is most important to the hospital?"
legal_answers_1 = {None, 'accuracy', 'precision', 'recall'}
"*** Your Answer Here ***"
student_answer_1 = 'recall'

"Which model should the hospital choose?"
legal_answers_2 = {None, 'knn', 'logistic regression', 'decision tree', 'neural network'}
"*** Your Answer Here ***"
student_answer_2 = 'logistic regression'
