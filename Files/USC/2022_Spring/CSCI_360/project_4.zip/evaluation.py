def get_eval_metrics(predicted_classes, true_class_labels):
    """
    Returns evaluation metrics for binary classification problem.
    (1 is the positive class, 0 is the negative class)

    :predicted_classes: a list of binary class predictions (1 or 0)
    :true_class_labels: a list of true classes (1 or 0)

    :returns: accuracy, precision, recall
    """
    true_total = 0
    tp_total = 0
    fp_total = 0
    fn_total = 0
    for a, b in zip(predicted_classes, true_class_labels):
        if a == b:
            true_total += 1
        if a == b and a == 1:
            tp_total += 1
        if a == 1 and b == 0:
            fp_total += 1
        if a == 0 and b == 1:
            fn_total += 1
    acc = float(true_total / len(predicted_classes))
    precision = float(tp_total / (tp_total + fp_total))
    recall = float(tp_total / (tp_total + fn_total))
    return acc, precision, recall
