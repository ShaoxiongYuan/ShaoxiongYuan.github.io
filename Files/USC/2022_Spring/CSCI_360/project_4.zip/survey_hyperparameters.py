"""
This documents contains the dictionary survey_hyperparameters which specifies the
values to perform grid search over when training the mental health model.
Feel free to modify however you like, but be aware that adding too
many configurations will slow training down.
"""
survey_hyperparameters = {
    'input_dim': [8],  # Do not change
    'output_dim': [2],  # Do not change
    'hidden_dim': [30, 100, 125, 512],
    'layers': [3, 5, 7],
    'learning_rate': [-0.1, -0.05, -0.01],
    'epochs': [50, 100],
    'batch_size': [1500, 1700, 2000],
}
