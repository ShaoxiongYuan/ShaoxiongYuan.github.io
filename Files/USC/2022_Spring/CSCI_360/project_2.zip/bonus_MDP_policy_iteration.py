# adapted from https://towardsdatascience.com/implement-policy-iteration-in-python-a-minimal-working-example-6bf6cc156ca9

# ----------------------------------------
# STEP ONE: choose a day to journal and observe states + actions
# ----------------------------------------

# ----------------------------------------
# STEP TWO: translate your observations into states + actions below
# ----------------------------------------
# list of m states [s_0, s_1, ..., s_m-1]
states = [
    'fixating on past mistakes',
    'calm',
    'anxious about the future',
    'blissful',
    'hopeful/excited about the future'
]
# list of n actions [a_0, a_1, ..., a_n-1]
actions = [
    'breathe and stretch',
    'hug a tree',
    'play the drum',
    'watch youtube'
]

# ----------------------------------------
# STEP THREE: follow intuition and try to assign rewards and transition probs
# ----------------------------------------

# direct rewards for being in state s
# NOTE: this is simpler alternative MDP formulation that gives agent
# reward for being in a given state s that is independent of how the agent transitioned into s
rewards = [-2, 1, -1, 2, 3]
assert(len(rewards) == len(states))

# Transition probabilities
# rows represent transitions from current state s
# columns represent transition to next state s'
# each entry is a list of transition probabilities across the action space:
#   probs[s][s'] = [T(s, a_0, s'), T(s, a_1, s'), ... , T(s, a_n-1, s')]
#   e.g. for me, probs[0][2] = [0.3, 0.2, 0.3, 0.2]
#       thus, T('fixating on past mistakes', 'breathe and stretch', 'anxious about the future') = probs[0][2][0] = 0.3
probs = [
    [[0.2, 0.1, 0.0, 0.5], [0.3, 0.3, 0.3, 0.3], [0.3, 0.2, 0.3, 0.2], [0.1, 0.2, 0.3, 0.0], [0.1, 0.2, 0.1, 0.0]],
    [[0.2, 0.1, 0.0, 0.5], [0.4, 0.3, 0.3, 0.3], [0.1, 0.2, 0.3, 0.2], [0.2, 0.2, 0.3, 0.0], [0.1, 0.2, 0.1, 0.0]],
    [[0.2, 0.1, 0.0, 0.2], [0.3, 0.3, 0.3, 0.3], [0.3, 0.2, 0.3, 0.5], [0.1, 0.2, 0.3, 0.0], [0.1, 0.2, 0.1, 0.0]],
    [[0.2, 0.1, 0.0, 0.5], [0.2, 0.3, 0.3, 0.3], [0.1, 0.2, 0.3, 0.2], [0.4, 0.2, 0.3, 0.0], [0.1, 0.2, 0.1, 0.0]],
    [[0.1, 0.1, 0.0, 0.5], [0.2, 0.3, 0.3, 0.3], [0.1, 0.2, 0.3, 0.2], [0.2, 0.2, 0.3, 0.0], [0.4, 0.2, 0.1, 0.0]]
    # [[0.0, 0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 0.0]]
]
assert(len(probs) == len(states))
for s in probs:
    assert(len(s) == len(states))
    for s_prime in s:
        assert(len(s_prime) == len(actions))

    for a, _ in enumerate(actions):
        # ensures that the transition probabilities sum to either:
        #   - 0 (action a is not available to state s)
        #   - 1 (transition probabilities of taking action a in state s sum to 1)
        prob_sum = sum([s_prime[a] for s_prime in s])
        assert(prob_sum == 0 or abs(prob_sum - 1) < 0.0001)

# ----------------------------------------
# STEP FOUR: run policy iteration; feel free to explore different parameters!
# ----------------------------------------

# Set policy iteration parameters
gamma = 0.9  # discount factor
delta = 0.01  # Error tolerance used to determine value convergence within policy evaluation
max_policy_iter = 1000  # Maximum number of policy iterations
max_value_iter = 1000  # Maximum number of value iterations within policy evaluation

# initialize pi to choose action a_0 for each state s
pi = {s: 0 for s in states}

# initialize V to 0 for each state s
V = {s: 0 for s in states}


for p_count in range(max_policy_iter):
    # Initial assumption: policy is stable
    optimal_policy_found = True

    # print(p_count)
    # print(pi)
    # print(V)
    # print()

    # Policy evaluation - dynamic programming approach
    # Compute new value for each state under current policy
    V_new = {s: 0 for s in states}  # Initialize values
    for v_count in range(max_value_iter):
        max_diff = 0  # Initialize max difference
        # print(v_count)
        # print(V_new)
        # print()

        for i, s in enumerate(states):

            # Compute state value
            val = rewards[i]  # Get direct reward for being in state s
            for j, s_next in enumerate(states):
                val += probs[i][j][pi[s]] * (
                        gamma * V_new[s_next]
                )  # Add discounted downstream values

            # Update maximum difference
            max_diff = max(max_diff, abs(val - V_new[s]))

            V_new[s] = val  # Update V[s] with value
        # If diff smaller than threshold delta for all states, algorithm terminates
        if max_diff < delta:
            break

    # update V given convergent V_new values calculated in policy evaluation
    for s in states:
        V[s] = V_new[s]

    # Policy iteration
    # With updated state values, improve policy if needed
    for i, s in enumerate(states):

        val_max = V[s]
        for a, _ in enumerate(actions):
            val = rewards[i]  # Get direct reward for being in state s
            for j, s_next in enumerate(states):
                val += probs[i][j][a] * (
                    gamma * V[s_next]
                )  # Add discounted downstream values

            # Update policy if (i) action improves value and (ii) action different from current policy
            if val > val_max and pi[s] != a:
                pi[s] = a
                val_max = val
                optimal_policy_found = False

    # If policy did not change, algorithm terminates
    if optimal_policy_found:
        break

# print policy
for s in states:
    print('s: {0}\n\tpi(s): {1}'.format(s, actions[pi[s]]))

# ----------------------------------------
# STEP FIVE: complete reflection questions: https://forms.gle/xwTo6UkgTz4PFTHi8
# ----------------------------------------
