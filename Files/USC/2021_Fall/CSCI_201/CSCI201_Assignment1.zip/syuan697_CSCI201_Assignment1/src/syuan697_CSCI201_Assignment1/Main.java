package syuan697_CSCI201_Assignment1;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

public class Main {
    private final WristCuff wc = new WristCuff();
    public String filename;

    /**
     * Uses GSON to read the file inputted by the user
     */
    private void readFile() {
        while (true) {
            Scanner input = new Scanner(System.in);
            System.out.print("Please provide timefall shelter data source: ");
            filename = input.nextLine().strip();
            try {
                Gson gson = new GsonBuilder().create();
                JsonReader reader = new JsonReader(new FileReader(filename));
                List<TimefallShelter> shelters = gson.fromJson(reader, new TypeToken<List<TimefallShelter>>() {
                }.getType());
                for (TimefallShelter shelter : shelters) {
                    if (shelter.getChiralFrequency() == null || shelter.getAddress() == null || shelter.getGuid() == null || shelter.getName() == null || shelter.getPhone() == null || shelter.isTimefall() == null) {
                        throw new IOException();
                    }
                    Pattern pattern = Pattern.compile("^\\s*\\+\\d+\\s*\\(\\d{3}\\)\\s*\\d{3}-\\d{4}\\s*$");
                    Matcher matcher = pattern.matcher(shelter.getPhone());
                    if (!matcher.matches()) {
                        throw new IllegalStateException();
                    }
                    pattern = Pattern.compile("^[0-9a-z]{8}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{12}$");
                    matcher = pattern.matcher(shelter.getGuid());
                    if (!matcher.matches()) {
                        throw new Exception();
                    }
                }
                wc.setShelter(shelters);
                System.out.println("=== Data accepted ===\n");
                break;
            } catch (FileNotFoundException e) {
                System.out.println("The file " + filename + " could not be found.");
            } catch (JsonParseException parseException) {
                System.out.println("Data cannot be converted to the proper type.");
            } catch (IOException ioException) {
                System.out.println("Missing data parameters.");
            } catch (IllegalStateException exception) {
                System.out.println("GUID format error.");
            } catch (Exception exception) {
                System.out.println("Phone number format error.");
            }
        }
    }

    /**
     * Gets the supported chiral frequencies from the user
     */
    private void setSupportedFrequencies() {
        while (true) {
            try {
                Scanner input = new Scanner(System.in);
                System.out.print("Please provide supported Chiral frequencies: ");
                String line = input.nextLine().strip();
                if (!line.equals("")) {
                    String[] freq = line.split("\\s*,\\s*");
                    wc.setFreq(freq);
                } else {
                    wc.setFreq(new String[]{});
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Please enter the frequencies in the right format: numbers separated by commas!");
            }
        }
    }

    /**
     * Prints the option menu
     */
    private void displayOptions() {
        System.out.println(
                """
                        \t1) List all available shelters within the min and max of supported Chiral frequencies
                        \t2) Search for a shelter by Chiral frequency
                        \t3) Search for a shelter by name
                        \t4) Sort shelters by Chiral frequency
                        \t5) Jump to a shelter with the lowest supported Chiral frequency
                        """
        );
    }

    public static void main(String[] args) throws Exception {
        Main solution = new Main();
        System.out.println("Welcome to Bridges Link.\n");
        solution.readFile();
        solution.setSupportedFrequencies();
        while (true) {
            solution.displayOptions();
            Scanner input = new Scanner(System.in);
            System.out.print("Choose an option: ");
            int choice;
            try {
                choice = input.nextInt();
                if (choice == 1) {
                    solution.wc.listAllShelters();
                } else if (choice == 2) {
                    while (true) {
                        input = new Scanner(System.in);
                        System.out.print("\nWhat Chiral frequency are you looking for? ");
                        int freq = input.nextInt();
                        boolean result = solution.wc.findByFreq(freq);
                        if (result) {
                            break;
                        }
                    }
                } else if (choice == 3) {
                    while (true) {
                        input = new Scanner(System.in);
                        System.out.print("\nWhat shelter�s name are you looking for? ");
                        String name = input.nextLine().strip();
                        boolean result = solution.wc.findByName(name);
                        if (result) {
                            break;
                        }
                    }
                } else if (choice == 4) {
                    try {
                        solution.wc.sortShelters(solution.filename);
                    } catch (IOException e) {
                        System.out.println("File Not Found!");
                    }
                } else if (choice == 5) {
                    System.out.println("\n=== Commencing timefall shelter search ===");
                    try {
                        solution.wc.findShelter(solution.filename);
                        break;
                    } catch (IOException e) {
                        System.out.println("File Not Found!");
                    }
                } else {
                    System.out.println("\nPlease choose another number!\n");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input!");
            }
        }
    }
}
