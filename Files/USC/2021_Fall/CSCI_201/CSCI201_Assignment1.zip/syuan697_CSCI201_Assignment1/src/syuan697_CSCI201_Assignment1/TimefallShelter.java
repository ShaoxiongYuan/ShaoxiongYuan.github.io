package syuan697_CSCI201_Assignment1;

/**
 * Here: all the needed class members and their getters and setters
 */
public class TimefallShelter implements Comparable<TimefallShelter> {
    private Integer chiralFrequency;
    private Boolean timefall;
    private String guid;
    private String name;
    private String phone;
    private String address;

    public TimefallShelter() {
    }

    public TimefallShelter(int freq, boolean timefall, String guid, String name, String phone, String address) {
        chiralFrequency = freq;
        this.timefall = timefall;
        this.guid = guid;
        this.name = name;
        this.phone = phone;
        this.address = address;
    }

    public Integer getChiralFrequency() {
        return chiralFrequency;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getGuid() {
        return guid;
    }

    public String getPhone() {
        return phone;
    }

    public Boolean isTimefall() {
        return timefall;
    }

    /**
     * overriding comparator for sorting
     */
    @Override
    public int compareTo(TimefallShelter compShelter) {
        /* For Ascending order*/
        return getChiralFrequency() - compShelter.getChiralFrequency();
    }

    /**
     * String representation of a shelter
     */
    @Override
    public String toString() {
        String isFall;
        if (timefall) {
            isFall = "Current";
        } else {
            isFall = "None";
        }
        return "Shelter Information: \n- Chiral frequency: " + chiralFrequency + "\n" + "- Timefall: " + isFall + "\n" + "- GUID: " + guid + "\n" + "- Name: " + name + "\n" + "- Phone: " + phone + "\n" + "- Address: " + address + "\n";
    }
}
