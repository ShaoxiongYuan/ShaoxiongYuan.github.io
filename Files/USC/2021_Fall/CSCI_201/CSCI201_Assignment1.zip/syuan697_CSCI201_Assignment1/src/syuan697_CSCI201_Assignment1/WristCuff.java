package syuan697_CSCI201_Assignment1;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class WristCuff {
    private Set<Integer> frequencies;
    private List<TimefallShelter> shelters;

    //set initial values for needed members
    public WristCuff() {
    }


    /**
     * List all available shelters within the min and max of supported Chiral frequencies
     */
    void listAllShelters() {
        ArrayList<TimefallShelter> tfs = new ArrayList<>();
        int count = 0;
        if (frequencies == null) {
            System.out.println("\n" + count + " result\n");
            return;
        }
        for (TimefallShelter shelter : shelters) {
            if (frequencies.contains(shelter.getChiralFrequency())&& !shelter.isTimefall()) {
                count++;
                tfs.add(shelter);
            }
        }
        if (count == 0 || count == 1) {
            System.out.println("\n" + count + " result\n");
        } else {
            System.out.println("\n" + count + " results\n");
        }
        for (TimefallShelter tf : tfs) {
            System.out.println(tf);
        }
    }


    /**
     * Search for a shelter by Chiral frequency
     */
    public boolean findByFreq(Integer freq) {
        for (TimefallShelter shelter : shelters) {
            if (shelter.getChiralFrequency().equals(freq)) {
                System.out.println(shelter);
                return true;
            }
        }
        System.out.println("\nThat Chiral frequency does not exist.");
        return false;

    }

    /**
     * Search for a shelter by name
     */
    public boolean findByName(String name) {
        for (TimefallShelter shelter : shelters) {
            if (shelter.getName().toLowerCase(Locale.ROOT).equals(name.toLowerCase(Locale.ROOT))) {
                System.out.println("\nFound!\n");
                System.out.println(shelter);
                return true;
            }
        }
        System.out.println("\nNo such shelter�");
        return false;
    }

    /**
     * Find an available shelter with the lowest supported Chiral frequency
     */
    public void findShelter(String filename) throws IOException {
        shelters.sort(Collections.reverseOrder());
        if (frequencies == null) {
            System.out.println("=== No shelter available. You are DOOMED. ===");
            return;
        }
        for (int i = shelters.size() - 1; i > -1; i--) {
            TimefallShelter shelter = shelters.get(i);
            int freq = shelter.getChiralFrequency();
            if (frequencies.contains(freq) && !shelter.isTimefall()) {
                System.out.println("=== Matching timefall shelter found! ===");
                System.out.println(shelter);
                System.out.println("=== Commencing Chiral jump, see you in safety. ===");
                return;
            } else if (frequencies.contains(freq) && shelter.isTimefall()) {
                System.out.println("=== Chiral frequency " + shelter.getChiralFrequency() + " unstable, Chiral jump unavailable. ===");
                System.out.println("=== Removing target shelter from the list of shelters and saving updated list to disk. ===\n");
                shelters.remove(shelter);
            }
        }
        save(filename);
        System.out.println("=== No shelter available. You are DOOMED. ===");
    }

    /**
     * Sort shelters by Chiral frequency
     */
    public void sortShelters(String filename) throws IOException {
        Collections.sort(shelters);
        save(filename);
        System.out.println("\nShelters successfully sorted by Chiral frequency.\n");
    }

    /**
     * Saves the updated list of shelters to disk
     */
    public void save(String filename) throws IOException {
        Gson gson = new Gson();
        Type listType = new TypeToken<List<TimefallShelter>>() {
        }.getType();
        Collections.sort(shelters);
        String json = gson.toJson(shelters, listType);
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
        writer.write(json);
        writer.close();
    }

    public void setShelter(List<TimefallShelter> allShelters) {
        shelters = allShelters;
    }

    public void setFreq(String[] freqs) {
        frequencies = Stream.of(freqs).mapToInt(Integer::parseInt).boxed().collect(Collectors.toSet());
    }
}
