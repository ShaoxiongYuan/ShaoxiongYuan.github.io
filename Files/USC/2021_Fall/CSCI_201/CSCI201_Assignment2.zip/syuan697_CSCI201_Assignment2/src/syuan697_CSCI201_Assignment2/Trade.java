package syuan697_CSCI201_Assignment2;

public class Trade extends Thread {
    private final Stock stock;
    private final Schedule schedule;

    public Trade(Stock stock, Schedule schedule) {
        this.stock = stock;
        this.schedule = schedule;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    /**
     * Trading function using locks
     */
    public void run() {
        try {
            stock.getSem().acquire();
            if (schedule.getNumTraded() > 0) {
                System.out.println("[" + Utility.getZeroTimestamp() + "]" + " Starting purchase of " + schedule.getNumTraded() + " stocks of " + schedule.getTicker());
            } else {
                System.out.println("[" + Utility.getZeroTimestamp() + "]" + " Starting sale of " + schedule.getNumTraded() * (-1) + " stocks of " + schedule.getTicker());
            }
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Interrupted.");
        } finally {
            if (schedule.getNumTraded() > 0) {
                System.out.println("[" + Utility.getZeroTimestamp() + "]" + " Finishing purchase of " + schedule.getNumTraded() + " stocks of " + schedule.getTicker());
            } else {
                System.out.println("[" + Utility.getZeroTimestamp() + "]" + " Finishing sale of " + schedule.getNumTraded() * (-1) + " stocks of " + schedule.getTicker());
            }
            stock.getSem().release();
        }
    }
}
