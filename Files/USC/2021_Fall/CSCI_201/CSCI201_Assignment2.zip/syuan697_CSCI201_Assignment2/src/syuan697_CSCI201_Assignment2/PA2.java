package syuan697_CSCI201_Assignment2;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class PA2 {
    static String stock_filename;
    static String schedule_filename;
    static List<Schedule> schedules = new ArrayList<>();
    static List<Stock> stocks;
    static ArrayList<Trade> trades = new ArrayList<>();

    /**
     * Read Stock Json File inputed by user using GSON
     */
    private static void readStockFile() {
        while (true) {
            Scanner input = new Scanner(System.in);
            System.out.print("What is the name of the file containing the company information? ");
            stock_filename = input.nextLine().strip();
            try {
                if (!stock_filename.endsWith(".json")) {
                    throw new IllegalArgumentException();
                }
                Gson gson = new GsonBuilder().create();
                JsonReader reader = new JsonReader(new FileReader(stock_filename));
                JsonObject stockMap = gson.fromJson(reader, JsonObject.class);
                stocks = gson.fromJson(stockMap.get("data"), new TypeToken<ArrayList<Stock>>() {
                }.getType());
                for (Stock stock : stocks) {
                    if (stock.getName() == null || stock.getStartDate() == null || stock.getTicker() == null || stock.getStockBrokers() == null || stock.getDescription() == null || stock.getExchangeCode() == null || stock.getTicker().equals("")) {
                        throw new Exception();
                    }
                    if (stock.getStockBrokers() <= 0) {
                        throw new IllegalStateException();
                    }
                }
                break;
            } catch (JsonParseException ie) {
                System.out.println("Cannot convert to the proper data type.");
            } catch (IOException ioException) {
                System.out.println("File " + stock_filename + " could not be found.");
            } catch (IllegalStateException ex) {
                System.out.println("Stockbroker number must be positive.");
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid file extension! Must be a json file!");
            } catch (Exception exception) {
                System.out.println("Missing data parameters.");
            }
        }
    }

    /**
     * Read Stock Trades CSV File inputed by user
     */
    private static void readScheduleFile() {
        while (true) {
            Scanner input = new Scanner(System.in);
            System.out.print("What is the name of the file containing the schedule information? ");
            schedule_filename = input.nextLine().strip();
            try {
                if (!schedule_filename.endsWith(".csv")) {
                    throw new IllegalStateException();
                }
                File file = new File(schedule_filename);
                Scanner scan = new Scanner(file);
                while (scan.hasNextLine()) {
                    String line = scan.nextLine();
                    String[] inputArr = line.split(",");
                    int time = Integer.parseInt(inputArr[0]);
                    String ticker = inputArr[1];
                    if (findStock(ticker) == null) {
                        throw new IOException();
                    }
                    int numTraded = Integer.parseInt(inputArr[2]);
                    Schedule schedule = new Schedule(time, ticker, numTraded);
                    schedules.add(schedule);
                }
                break;
            } catch (IllegalStateException exception) {
                System.out.println("Invalid file extension! Must be a csv file!");
            } catch (FileNotFoundException e) {
                System.out.println("File " + schedule_filename + " could not be found.");
            } catch (NumberFormatException ie) {
                System.out.println("The first and third columns must be integers.");
            } catch (IOException ioException) {
                System.out.println("Cannot find stock in stock list.");
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.out.println("Missing data parameter.");
            }
        }
    }

    /**
     * Set up Semaphore for Stock Brokers
     */
    private static void initializeSemaphor() {
        for (Schedule schedule : schedules) {
            String ticker = schedule.getTicker();
            Stock stock = findStock(ticker);
            assert stock != null;
            Semaphore sem = new Semaphore(stock.getStockBrokers());
            stock.setSem(sem);
            Trade trade = new Trade(stock, schedule);
            trades.add(trade);
        }
    }

    private static Stock findStock(String ticker) {
        for (Stock stock : stocks) {
            if (stock.getTicker().equals(ticker)) {
                return stock;
            }
        }
        return null;
    }

    private static void executeTrades() {
        ExecutorService exec = Executors.newFixedThreadPool(trades.size());
        for (Trade trade : trades) {
            int curr_second = Integer.parseInt(Utility.getZeroTimestamp().substring(6, 8));
            int curr_minute = Integer.parseInt(Utility.getZeroTimestamp().substring(3, 5));
            int curr_hour = Integer.parseInt(Utility.getZeroTimestamp().substring(0, 2));
            int time = trade.getSchedule().getTime();
            long hours = TimeUnit.SECONDS.toHours(time);
            long minutes = TimeUnit.SECONDS.toMinutes(time)
                    - TimeUnit.HOURS.toMinutes(TimeUnit.SECONDS.toHours(time));
            long seconds = TimeUnit.SECONDS.toSeconds(time)
                    - TimeUnit.MINUTES.toSeconds(TimeUnit.SECONDS.toMinutes(time));
            while (!(curr_second == seconds && curr_minute == minutes && curr_hour == hours)) {
                curr_second = Integer.parseInt(Utility.getZeroTimestamp().substring(6, 8));
                curr_minute = Integer.parseInt(Utility.getZeroTimestamp().substring(3, 5));
                curr_hour = Integer.parseInt(Utility.getZeroTimestamp().substring(0, 2));
            }
            exec.execute(trade);
        }
        exec.shutdown();
        while (!exec.isTerminated()) {
            Thread.yield();
        }
        System.out.println("All trades completed!");
    }

    public static void main(String[] args) {
        readStockFile();
        readScheduleFile();
        initializeSemaphor();
        executeTrades();
    }
}
