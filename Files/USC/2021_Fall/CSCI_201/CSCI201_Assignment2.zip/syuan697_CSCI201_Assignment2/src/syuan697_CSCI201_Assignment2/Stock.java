package syuan697_CSCI201_Assignment2;

import java.util.concurrent.Semaphore;

public class Stock {
    /**
     * Here: all the needed class members and their getters and setters
     */
    private String name;
    private String ticker;
    private String startDate;
    private Integer stockBrokers;
    private String description;
    private String exchangeCode;

    private transient Semaphore sem;

    public Stock() {
    }

    public String getName() {
        return name;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getDescription() {
        return description;
    }

    public String getExchangeCode() {
        return exchangeCode;
    }

    public Semaphore getSem() {
        return sem;
    }

    public void setSem(Semaphore sem) {
        this.sem = sem;
    }

    public String getTicker() {
        return ticker;
    }

    public Integer getStockBrokers() {
        return stockBrokers;
    }

    /**
     * String representation of a stock
     */
    @Override
    public String toString() {
        return "Stock Information: \n- Name: " + name + "\n" + "- Ticker: " + ticker + "\n";
    }
}
