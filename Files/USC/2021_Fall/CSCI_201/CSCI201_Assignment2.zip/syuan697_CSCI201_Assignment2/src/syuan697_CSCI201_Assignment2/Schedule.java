package syuan697_CSCI201_Assignment2;

public class Schedule {
    private final int time;
    private final String ticker;
    private final int numTraded;


    /**
     * Stock Trades Schedule
     * Keep the track of tasks
     */
    public Schedule(int time, String ticker, int numTraded) {
        this.time = time;
        this.ticker = ticker;
        this.numTraded = numTraded;
    }

    public int getTime() {
        return time;
    }

    public String getTicker() {
        return ticker;
    }

    public int getNumTraded() {
        return numTraded;
    }
}
