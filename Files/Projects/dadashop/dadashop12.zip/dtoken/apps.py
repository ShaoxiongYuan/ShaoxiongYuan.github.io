from django.apps import AppConfig


class DtokenConfig(AppConfig):
    name = 'dtoken'
