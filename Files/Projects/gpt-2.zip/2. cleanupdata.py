import os
from colorama import Fore

# remove non-py files
for dirpath, dirnames, filenames in os.walk('repos'):
    for f in filenames:
        full_path = os.path.join(dirpath, f)
        if not full_path.endswith('.py'):
            print(f'{Fore.RED}Deleting {full_path}')
            os.remove(full_path)
        else:
            print(f'{Fore.GREEN}Keeping {full_path}')

# remove empty dirs
for dirpath, dirnames, filenames in os.walk('repos'):
    if not os.listdir(dirpath):
        os.removedirs(dirpath)
