import os

MAX_CHAR_LENGTH = 512
MIN_CHAR_LENGTH = 256
NEWLINECHAR = '<N>'

full_paths = []
for dirpath, dirnames, filenames in os.walk('repos'):
    for f in filenames:
        full_path = os.path.join(dirpath, f)
        full_paths.append(full_path)

print(len(full_paths))

with open('python_code_text_data.txt', 'a') as f:
    for fpath in full_paths:
        try:
            d = open(fpath, encoding='utf-8').read()
            fd = d.replace('\n', NEWLINECHAR)
            if 100 < len(fd) < MAX_CHAR_LENGTH:
                f.write(fd + '\n')
            else:
                sd = fd.split(f'{NEWLINECHAR}{NEWLINECHAR}')
                substr = ''
                for split in sd:
                    substr += split + f'{NEWLINECHAR}{NEWLINECHAR}'
                    if MIN_CHAR_LENGTH <= len(substr) <= MAX_CHAR_LENGTH:
                        f.write(substr + '\n')
                        substr = ''
        except Exception as e:
            print(str(e))
