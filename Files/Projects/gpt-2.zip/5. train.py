from transformers import GPT2Config, GPT2LMHeadModel, GPT2Tokenizer, \
    DataCollatorForLanguageModeling, Trainer, \
    TrainingArguments
from datasets import load_dataset

paths = ['python_code_text_data.txt']

tokenizer = GPT2Tokenizer.from_pretrained('tokenizer')
tokenizer.add_special_tokens({
    'bos_token': '<s>',
    'eos_token': '</s>',
    'unk_token': '<unk>',
    'mask_token': '<mask>',
    'pad_token': '<pad>'
})

config = GPT2Config(vocab_size=tokenizer.vocab_size, bos_token_id=tokenizer.bos_token_id,
                    eos_token_id=tokenizer.eos_token_id)
model = GPT2LMHeadModel(config)

dataset = load_dataset('text', data_files=paths)


def encode(lines):
    return tokenizer(lines['text'], add_special_tokens=True, truncation=True, max_length=512)


dataset.set_transform(encode)
dataset = dataset['train']

data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer)

training_args = TrainingArguments(
    output_dir='Self-Trained-Model',
    overwrite_output_dir=True,
    num_train_epochs=1,
    per_gpu_train_batch_size=1,
    save_steps=1000,
    save_total_limit=2,
    prediction_loss_only=True
)
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset,
    data_collator=data_collator
)
trainer.train()
trainer.save_model('Self-Trained-Model')
