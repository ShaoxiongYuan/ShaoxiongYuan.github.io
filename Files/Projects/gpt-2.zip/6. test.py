from transformers import GPT2LMHeadModel, GPT2Tokenizer
import warnings

warnings.filterwarnings('ignore')

tokenizer = GPT2Tokenizer.from_pretrained('GPyT/tokenizer')
tokenizer.add_special_tokens({
    'bos_token': '<s>',
    'eos_token': '</s>',
    'unk_token': '<unk>',
    'mask_token': '<mask>',
    'pad_token': '<pad>'
})

model = GPT2LMHeadModel.from_pretrained('GPyT/model').to('cuda')

NEWLINECHAR = '<N>'


def encode_newlines(inp):
    return inp.replace('\n', NEWLINECHAR)


def decode_newlines(inp):
    return inp.replace(NEWLINECHAR, '\n')


def auto_complete(inp):
    inp = encode_newlines(inp)

    newline_count = inp.count(NEWLINECHAR)
    inp_ids = tokenizer.encode(inp, return_tensors='pt').to('cuda')

    beam_output = model.generate(inp_ids,
                                 max_length=100,
                                 num_beams=3,
                                 temperature=0.7,
                                 no_repeat_ngram_size=5,
                                 num_return_sequences=3,
                                 return_dict_in_generate=True,
                                 output_scores=True)

    sequence = beam_output['sequences'][0]

    decoded = decode_newlines(tokenizer.decode(sequence))

    print('-' * 20)
    print(decoded)
    print('-' * 20)
    print()
    print()

    complete = ''
    split = decoded.split('\n')
    for s in split[:newline_count + 1]:
        complete += s + '\n'

    return complete


inp = """import matplotlib.pyplot as plt
import numpy as np

x=range(5)
"""
print('Autocompleted:\n')
print(auto_complete(inp))
