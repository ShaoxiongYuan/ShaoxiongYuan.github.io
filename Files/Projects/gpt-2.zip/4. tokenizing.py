from tokenizers.implementations import ByteLevelBPETokenizer

paths = ['python_code_text_data.txt']

tokenizer = ByteLevelBPETokenizer()
tokenizer.train(files=paths, special_tokens=['<s>', '<pad>', '</s>', '<unk>', '<mask>'])
tokenizer.save_model('./tokenizer')
